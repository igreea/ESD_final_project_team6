from picamera2 import Picamera2
import cv2
import numpy as np
import time

# 해상도 설정
HIGH_RES = (1280, 1280)
LOW_RES = (192, 192)

# 전역 프레임 버퍼
high_res_frame = None
low_res_frame = None
dets = []
results = []
cap_signal = False
inference_signal = False

# 추론시간, fps측정
low_fps_list = []
high_fps_list = []
inference_times = []


def capture_thread_webcam(picam2):
    """
    카메라에서 프레임을 캡처하여 원본 프레임은 high_res_frame에,
    저해상도 프레임은 low_res_frame에 저장
    :param picam2: Picamera2 객체
    """

    global high_res_frame, low_res_frame, cap_signal
    while True:
        hi = picam2.capture_array("main")
        high_res_frame = hi
        low_res_frame = cv2.resize(high_res_frame, LOW_RES, interpolation=cv2.INTER_AREA)
        cap_signal = True


def detect_thread(model):
    """
    low_res_frame에서 YOLO 모델을 사용하여 사람 감지
    xyxy는 yolo에서 제공하는 attribute로, [x1, y1, x2, y2, conf, cls]를 포함
    :param model: YOLO 모델 객체
    """
    global low_res_frame, results, dets, cap_signal, inference_signal
    while True:
        #if cap_signal == False:  #새로 캡쳐 됐을 때만 추론
        #    continue
        results = model(source=low_res_frame, imgsz = LOW_RES, classes=[0])
        #inference_signal = True
        dets = results[0].boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2, conf, cls]
        inference_time = results[0].speed["inference"]  # YOLOv8/v11은 리스트 반환
        inference_times.append(inference_time)


def display_thread(picam2):
    """
    고해상도 프레임과 저해상도 프레임을 각기 다른 창에 표시
    :param picam2: Picamera2 객체
    """
    global high_res_frame, low_res_frame, dets, fps_list, inference_times, cap_signal, inference_signal
    win_hi = "High-Res"
    win_lo = "Low-Res"
    blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임
    sx = HIGH_RES[0] / LOW_RES[0] # 저해상도에서 고해상도로 변환할 때 x축 비율
    sy = HIGH_RES[1] / LOW_RES[1] # 저해상도에서 고해상도로 변환할 때 y축 비율
    cv2.namedWindow(win_hi, cv2.WINDOW_AUTOSIZE)
    cv2.namedWindow(win_lo, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win_lo, 640, 640) #640x640으로 크기 조정

    low_prev_time = time.time()
    hi_prev_time = time.time()
    while True:
        # 프레임 먼저   -> blocking 제거
        if cap_signal == False:
            time.sleep(0.000001)
            continue
        cap_signal = False
        cv2.imshow(win_lo, low_res_frame)
        low_current_time = time.time()
        low_fps = 1.0 / (low_current_time - low_prev_time)
        low_fps_list.append(low_fps)
        low_prev_time = low_current_time
        if cv2.waitKey(1) & 0xFF == ord('q'):
                print(f"평균 low_fps: {sum(low_fps_list)/len(low_fps_list):.2f} ")
                print(f"평균 high_fps: {sum(high_fps_list)/len(high_fps_list):.2f} ")
                print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
                break

        # Draw bounding boxes
        if dets is not None and len(dets) > 0:
            dets_to_show = dets[:2] if len(dets) > 2 else dets
            dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
            patches = []
            for box in dets_to_show:
                x1, y1, x2, y2 = map(int, box[:4])
                hr1, hr2 = int(x1*sx), int(y1*sy)
                hr3, hr4 = int(x2*sx), int(y2*sy)
                roi = high_res_frame[hr2:hr4, hr1:hr3]
                if roi.size:
                    patches.append(roi)
            if len(patches) > 1:
                h1, w1 = patches[0].shape[:2]
                h2, w2 = patches[1].shape[:2]
                canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
                canvas[:h1, :w1] = patches[0]
                canvas[:h2, w1:w1+w2] = patches[1]
                cv2.imshow(win_hi, canvas)
            else:
                cv2.imshow(win_hi, patches[0])
        else:
            cv2.imshow(win_hi, blank)  # 빈 프레임 표시
        hi_current_time = time.time()
        hi_fps = 1.0 / (hi_current_time - hi_prev_time)
        high_fps_list.append(hi_fps)
        hi_prev_time = hi_current_time
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            pass

    cv2.destroyAllWindows()
    picam2.stop()

