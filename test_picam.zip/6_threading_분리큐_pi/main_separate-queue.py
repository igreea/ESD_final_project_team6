import threading
import cv2
from ultralytics import YOLO
from util_separate import capture_thread_webcam, detect_thread, display_thread
from picamera2 import Picamera2
'''

'''


# 모델 로드 및 설정
model = YOLO("yolo11n.pt")
model.classes = [0]  # 사람 클래스만


HIGH_RES = (1280, 1280)
LOW_RES = (192, 192)

#picam
picam2 = Picamera2()
preview_config = picam2.create_preview_configuration(main={"size": HIGH_RES, "format": "RGB888"})
picam2.configure(preview_config)
picam2.start()


# 스레드 시작
threads = [
    threading.Thread(target=capture_thread_webcam, args=(picam2,), daemon=True),
    threading.Thread(target=detect_thread, args=(model,), daemon=True),
    threading.Thread(target=display_thread, args=(picam2,), daemon=False)
]

for t in threads:
    t.start()

for t in threads:
    t.join()
