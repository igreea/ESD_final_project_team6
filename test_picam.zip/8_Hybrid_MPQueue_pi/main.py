import cv2
import numpy as np
import threading
#import onnxruntime as ort
import time
from queue import Empty, Full
from ultralytics import YOLO
import util
from multiprocessing import Process, Queue as MPQueue, Event
from multiprocessing import Value
from picamera2 import Picamera2
'''

'''

def detect_process(frame_queue, det_queue, stop_event, skip_rate, model, skipping, low_res):
    #from ultralytics import YOLO
    model = YOLO(model, task="detect")
    model.classes = [0]
    #frame_count = 0

    inference_times = []
    while not stop_event.is_set():
        '''    
        frame_count += 1
        if frame_count % skip_rate != 0:
            skipping.value = True
            continue
        skipping.value = False
        '''
        try:
            lo, _ = frame_queue.get_nowait()
        except Empty:
            continue

        results = model(lo, imgsz=low_res)
        skipping.value += 1
        inference_time = results[0].speed["inference"]
        inference_times.append(inference_time)
        dets = results[0].boxes.xyxy.cpu().numpy()

        try:
            det_queue.get_nowait()
        except Empty:
            pass
        try:
            det_queue.put(dets, block=False)
        except:
            pass
    print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
    


class CameraProcessor:
    def __init__(
            self,
            model,
            high_res: tuple = (1280, 1280),
            low_res: tuple = (192, 192),
            max_queue_size: int = 1,
            skip_rate: int = 10     # n번마다 추론
            ):
        self.model = model

        self.high_res = high_res
        self.low_res = low_res
        
        self.skip_rate = skip_rate
        self.skipping = Value('i', 0)

        #picam
        self.picam2 = Picamera2()
        self.preview_config = self.picam2.create_preview_configuration(main={"size": HIGH_RES, "format": "RGB888"})
        self.picam2.configure(self.preview_config)
        self.picam2.start()

        
        self.max_queue_size = max_queue_size
        self.frame_queue = MPQueue(maxsize=max_queue_size)
        self.det_queue = MPQueue(maxsize=max_queue_size) 
        self.stop_event = None

        self.sx = high_res[0] / low_res[0] # 저해상도에서 고해상도로 변환할 때 x축 비율
        self.sy = high_res[1] / low_res[1] # 저해상도에서 고해상도로 변환할 때 y축 비율
        self.blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임

        # 추론시간, fps측정
        self.low_fps_list = []
        self.high_fps_list = []
        

    def _capture_loop(self) -> None:
        """
        picamera2에서 프레임을 캡처하여 lo_queue와 hi_queue에 저장하는 스레드
        :return: None
        """
        while not self.stop_event.is_set():
            high = self.picam2.capture_array("main")
            low = cv2.resize(high, self.low_res, interpolation=cv2.INTER_AREA)
            
            # 큐 비우고 최신 프레임만 유지
            try:
                self.frame_queue.get_nowait()
            except Empty:
                pass  # 큐가 비어 있으면 그대로 진행

            # 프레임 넣기 (실패해도 멈추지 않음)
            try:
                self.frame_queue.put((low, high), block=False)
            except Full:
                pass  # 안전하게 무시하고 다음 프레임으로 진행   
        self.picam2.stop()

    def _display_loop(self) -> None:
        win_hi = "High-Res"
        win_lo = "Low-Res"
        cv2.namedWindow(win_hi, cv2.WINDOW_AUTOSIZE)
        cv2.namedWindow(win_lo, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(win_lo, 640, 640) #640x640으로 크기 조정
        low_prev_time = time.time()
        hi_prev_time = time.time()
        dets = None
        temp = 0
        while not self.stop_event.is_set():
            # 프레임 먼저
            try:
                lo, hi = self.frame_queue.get(timeout=0.05)
                cv2.imshow(win_lo, lo)
                low_current_time = time.time()
                low_fps = 1.0 / (low_current_time - low_prev_time)
                self.low_fps_list.append(low_fps)
                low_prev_time = low_current_time
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    self.stop_event.set()
                    print(f"평균 low_fps: {sum(self.low_fps_list)/len(self.low_fps_list):.2f} ")
                    print(f"평균 high_fps: {sum(self.high_fps_list)/len(self.high_fps_list):.2f} ")
                    break

            except Empty:
                continue
            
            # skip 중일 때만 이전 박스 유지
            if self.skipping.value != temp:
                temp = self.skipping.value
                try:
                    dets= self.det_queue.get_nowait()   # 무조건 추론 후 진입 nowait
                except Empty:       # det_queue가 비어있으면 추론된게 없는거
                    dets = None
                    pass  

            # Draw bounding boxes
            if dets is not None and len(dets) > 0:
                dets_to_show = dets[:2] if len(dets) > 2 else dets
                dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
                patches = []
                for box in dets_to_show:
                    x1, y1, x2, y2 = map(int, box[:4])
                    hr1, hr2 = int(x1*self.sx), int(y1*self.sy)
                    hr3, hr4 = int(x2*self.sx), int(y2*self.sy)
                    roi = hi[hr2:hr4, hr1:hr3]
                    if roi.size:
                        patches.append(roi)
                if len(patches) > 1:
                    h1, w1 = patches[0].shape[:2]
                    h2, w2 = patches[1].shape[:2]
                    canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
                    canvas[:h1, :w1] = patches[0]
                    canvas[:h2, w1:w1+w2] = patches[1]
                    cv2.imshow(win_hi, canvas)
                else:
                    cv2.imshow(win_hi, patches[0])
            else:
                cv2.imshow(win_hi, self.blank)  # 빈 프레임 표시

            hi_current_time = time.time()
            hi_fps = 1.0 / (hi_current_time - hi_prev_time)
            self.high_fps_list.append(hi_fps)
            hi_prev_time = hi_current_time

        
            if cv2.waitKey(1) & 0xFF == ord('q'):
                pass

        cv2.destroyAllWindows()

    def run(self):
        self.stop_event = Event()

        detect_proc = Process(
            target=detect_process,
            args=(self.frame_queue, self.det_queue, self.stop_event, self.skip_rate, self.model, self.skipping, self.low_res),
        )

        threads = [
            threading.Thread(target=self._capture_loop, daemon=True),
            threading.Thread(target=self._display_loop)
        ]
        detect_proc.start()
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        detect_proc.join()
    

if __name__ == "__main__":
    HIGH_RES = (1280, 1280)  # 고해상도 해상도
    LOW_RES = (192, 192)  # 저해상도 해상도

    
    #model = YOLO("yolo11n.pt")
    processor = CameraProcessor(model="yolo11n.pt", high_res=HIGH_RES, low_res=LOW_RES, skip_rate=10)
    processor.run()

