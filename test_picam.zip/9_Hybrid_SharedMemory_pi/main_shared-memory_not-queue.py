import cv2
import numpy as np
import threading
#import onnxruntime as ort
import time
from queue import Empty, Full
from ultralytics import YOLO
#import util
from multiprocessing import Process, Event, Value
from multiprocessing import Queue as MPQueue
from multiprocessing.shared_memory import SharedMemory
from picamera2 import Picamera2
'''

'''

def detect_process(det_queue, stop_event, skip_rate, model, skipping, shape, low_res, new_frame_flag, shm_name, dtype):
    #from ultralytics import YOLO
    model = YOLO(model, task="detect")
    model.classes = [0]
    #frame_count = 0

    inference_times = []
    shm = SharedMemory(name=shm_name)
    np_low = np.ndarray(shape=shape, dtype=dtype, buffer=shm.buf)

    while not stop_event.is_set():
        '''    
        frame_count += 1
        if frame_count % skip_rate != 0:
            skipping.value = True
            continue
        skipping.value = False
        '''
        if new_frame_flag.value == False:
            #time.sleep(0.001)
            continue
        new_frame_flag.value = False

        lo = np_low.copy()  # 저화질 프레임

        results = model(lo, imgsz=low_res)
        skipping.value += 1
        inference_time = results[0].speed["inference"]
        inference_times.append(inference_time)

        dets = results[0].boxes.xyxy.cpu().numpy()
        try:
            det_queue.get_nowait()
        except Empty:
            pass
        try:
            det_queue.put(dets, block=False)
        except:
            pass
    shm.close()
    print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
    


class CameraProcessor:
    def __init__(
            self,
            model,
            high_res: tuple = (1280, 1280),
            low_res: tuple = (192, 192),
            max_queue_size: int = 1,
            skip_rate: int = 10     # n번마다 추론
            ):
        self.model = model
        self.high_res = high_res
        self.low_res = low_res
        
        self.skip_rate = skip_rate
        self.skipping = Value('i', 0)

        #picam
        self.picam2 = Picamera2()
        self.preview_config = self.picam2.create_preview_configuration(main={"size": HIGH_RES, "format": "RGB888"})
        self.picam2.configure(self.preview_config)
        self.picam2.start()

        self.stop_event = None
        self.new_frame_flag = Value('b', False)
        self.new_low_ready = False

        self.latest_high = None
        self.max_queue_size = max_queue_size
        #self.frame_queue = MPQueue(maxsize=max_queue_size)
        self.det_queue = MPQueue(maxsize=max_queue_size) 

        self.low_shape = (low_res[1], low_res[0], 3)
        self.dtype = np.uint8
        self.shm = SharedMemory(create=True, size=np.zeros(self.low_shape, dtype=self.dtype).nbytes)
        self.np_low = np.ndarray(self.low_shape, dtype=self.dtype, buffer=self.shm.buf)
        

        self.sx = high_res[0] / low_res[0] # 저해상도에서 고해상도로 변환할 때 x축 비율
        self.sy = high_res[1] / low_res[1] # 저해상도에서 고해상도로 변환할 때 y축 비율
        self.blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임

        # 추론시간, fps측정
        self.fps_list = []

    def _capture_loop(self) -> None:
        while not self.stop_event.is_set():
            high = self.picam2.capture_array("main")
            low = cv2.resize(high, self.low_res, interpolation=cv2.INTER_AREA)
            
            self.np_low[:] = low
            self.latest_high = high
            self.new_frame_flag.value = True
            self.new_low_ready = True
            print("((") 
        self.picam2.stop()

    def _display_loop(self) -> None:
        win_hi, win_lo= "High-Res", "Low-Res"        
        cv2.namedWindow(win_hi, cv2.WINDOW_AUTOSIZE)
        cv2.namedWindow(win_lo, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(win_lo, 640, 640) #640x640으로 크기 조정
        st_time = 0.01
        dets = None
        temp = 0

        while not self.stop_event.is_set():
            # 프레임 먼저
            if self.new_low_ready == False:
                # print("~~")
                #time.sleep(0.001)
                continue
            
            lo_disp = cv2.resize(self.latest_high, self.low_res)
            cv2.imshow(win_lo, lo_disp)
            low_current_time = time.time()
            low_fps = 1.0 / (low_current_time - low_prev_time)
            self.low_fps_list.append(low_fps)
            low_prev_time = low_current_time
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.stop_event.set()
                print(f"평균 low_fps: {sum(self.low_fps_list)/len(self.low_fps_list):.2f} ")
                print(f"평균 high_fps: {sum(self.high_fps_list)/len(self.high_fps_list):.2f} ")
                break
            
            # skip 중일 때만 이전 박스 유지
            if self.skipping.value != temp:
                temp = self.skipping.value
                try:
                    dets= self.det_queue.get_nowait()   # 무조건 추론 후 진입 nowait
                except Empty:       # det_queue가 비어있으면 추론된게 없는거
                    dets = None
                    pass  

            # Draw bounding boxes
            if dets is not None and len(dets) > 0:
                dets_to_show = dets[:2] if len(dets) > 2 else dets
                dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
                patches = []
                for box in dets_to_show:
                    x1, y1, x2, y2 = map(int, box[:4])
                    hr1, hr2 = int(x1*self.sx), int(y1*self.sy)
                    hr3, hr4 = int(x2*self.sx), int(y2*self.sy)
                    roi = self.latest_high[hr2:hr4, hr1:hr3]
                    if roi.size:
                        patches.append(roi)
                if len(patches) > 1:
                    h1, w1 = patches[0].shape[:2]
                    h2, w2 = patches[1].shape[:2]
                    canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
                    canvas[:h1, :w1] = patches[0]
                    canvas[:h2, w1:w1+w2] = patches[1]
                    cv2.imshow(win_hi, canvas)
                else:
                    cv2.imshow(win_hi, patches[0])
            else:
                cv2.imshow(win_hi, self.blank)  # 빈 프레임 표시

            hi_current_time = time.time()
            hi_fps = 1.0 / (hi_current_time - hi_prev_time)
            self.high_fps_list.append(hi_fps)
            hi_prev_time = hi_current_time
        
            if cv2.waitKey(1) & 0xFF == ord('q'):
                pass

        cv2.destroyAllWindows()

    def run(self):
        self.stop_event = Event()
        detect_proc = Process(
            target=detect_process,
            args=(self.det_queue, self.stop_event, self.skip_rate, self.model, self.skipping, self.low_shape, self.low_res, self.new_frame_flag, self.shm.name, self.dtype),
        )

        threads = [
            threading.Thread(target=self._capture_loop, daemon=True),
            threading.Thread(target=self._display_loop)
        ]
        detect_proc.start()
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        detect_proc.join()
        self.shm.close()
        self.shm.unlink()
    

if __name__ == "__main__":
    HIGH_RES = (1280, 1280)  # 고해상도 해상도
    LOW_RES = (192, 192)  # 저해상도 해상도

    
    #model = YOLO("yolo11n.pt")
    processor = CameraProcessor(model="yolo11n.pt", high_res=HIGH_RES, low_res=LOW_RES, skip_rate=10)
    processor.run()

