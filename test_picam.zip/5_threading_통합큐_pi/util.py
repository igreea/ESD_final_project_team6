import cv2
import numpy as np
import threading
from queue import Queue, Empty,    Full
import time
# 해상도 설정
HIGH_RES = (1280, 1280)
LOW_RES = (192, 192)

# 고정 비율 X → 해상도 비율로 정확 변환
sx = HIGH_RES[0] / LOW_RES[0]
sy = HIGH_RES[1] / LOW_RES[1]

# 추론시간, fps측정
low_fps_list = []
high_fps_list = []
inference_times = []


max_queue_size = 1
frame_queue = Queue(maxsize=max_queue_size)
det_queue = Queue(maxsize=max_queue_size)

stop_event = threading.Event()

def capture_thread_webcam(picam2):
    """
    카메라에서 프레임을 캡처하여 원본 프레임은 hi_queue에,
    저해상도 프레임은 lo_queue에 저장
    """
    global frame_queue, stop_event
    while not stop_event.is_set():
        high = picam2.capture_array("main")
        low = cv2.resize(high, LOW_RES, interpolation=cv2.INTER_AREA)
        
        try:
            frame_queue.get_nowait()
        except Empty:
            pass  # 큐가 비어 있으면 그대로 진행

        # 프레임 넣기 (실패해도 멈추지 않음)
        try:
            frame_queue.put((low, high), block=False)
        except Full:
            pass  # 안전하게 무시하고 다음 프레임으로 진행
    picam2.stop()


def detect_thread(model):
    """
    lo_queue에서 YOLO 모델을 사용하여 사람 감지
    xyxy는 yolo에서 제공하는 attribute로, [x1, y1, x2, y2, conf, cls]를 포함
    :param model: YOLO 모델 객체
    """
    global frame_queue, det_queue, stop_event, inference_times
    while not stop_event.is_set():
        try:
            frame, _ = frame_queue.get(timeout=0.05)
        except Empty:
            continue
        results = model(frame, imgsz=LOW_RES)
        inference_time = results[0].speed["inference"]  # YOLOv8/v11은 리스트 반환
        inference_times.append(inference_time)
        dets = results[0].boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2]
        if det_queue.full():
            det_queue.get_nowait()
        det_queue.put(dets)

def display_thread(picam2):
    global frame_queue, det_queue, stop_event, sx, sy, fps_list
    win_hi = "High-Res"
    win_lo = "Low-Res"
    blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임

    cv2.namedWindow(win_hi, cv2.WINDOW_AUTOSIZE)
    cv2.namedWindow(win_lo, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win_lo, 640, 640) #640x640으로 크기 조정

    low_prev_time = time.time()
    hi_prev_time = time.time()
    while not stop_event.is_set():
        
        try:
            lo, hi = frame_queue.get(timeout=0.05)
            cv2.imshow(win_lo, lo)
            low_current_time = time.time()
            low_fps = 1.0 / (low_current_time - low_prev_time)
            low_fps_list.append(low_fps)
            low_prev_time = low_current_time
            if cv2.waitKey(1) & 0xFF == ord('q'):
                stop_event.set()
                print(f"평균 low_fps: {sum(low_fps_list)/len(low_fps_list):.2f} ")
                print(f"평균 high_fps: {sum(high_fps_list)/len(high_fps_list):.2f} ")
                print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
                break
        except Empty:
            continue  

        try:
            dets = det_queue.get_nowait()
        except Empty:
            continue
        

        if dets is not None and len(dets) > 0:
            dets_to_show = dets[:2] if len(dets) > 2 else dets
            dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
            patches = []
            for box in dets_to_show:
                x1, y1, x2, y2 = map(int, box[:4])
                hr1, hr2 = int(x1*sx), int(y1*sy)
                hr3, hr4 = int(x2*sx), int(y2*sy)
                roi = hi[hr2:hr4, hr1:hr3]
                if roi.size:
                    patches.append(roi)
            if len(patches) > 1:
                h1, w1 = patches[0].shape[:2]
                h2, w2 = patches[1].shape[:2]
                canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
                canvas[:h1, :w1] = patches[0]
                canvas[:h2, w1:w1+w2] = patches[1]
                cv2.imshow(win_hi, canvas)
            else:
                cv2.imshow(win_hi, patches[0])
        else:
            cv2.imshow(win_hi, blank)  # 빈 프레임 표시
        hi_current_time = time.time()
        hi_fps = 1.0 / (hi_current_time - hi_prev_time)
        high_fps_list.append(hi_fps)
        hi_prev_time = hi_current_time
        if cv2.waitKey(1) & 0xFF == ord('q'):
            pass

    picam2.stop()
    cv2.destroyAllWindows()