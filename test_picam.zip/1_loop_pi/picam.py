import cv2
from ultralytics import YOLO
import time
import numpy as np
from picamera2 import Picamera2
'''

'''



# 모델 로드 및 설정

model = YOLO("yolo11n.pt")
model.classes = [0]  # 사람 클래스만

# 해상도 설정
HIGH_RES = (1280, 1280)
LOW_RES = (192, 192)

# 고정 비율 X → 해상도 비율로 정확 변환
sx = HIGH_RES[0] / LOW_RES[0]
sy = HIGH_RES[1] / LOW_RES[1]

# 추론시간, fps측정
fps_list = []
inference_times = []

#picam
picam2 = Picamera2()
preview_config = picam2.create_preview_configuration(main={"size": HIGH_RES, "format":"RGB888"})
picam2.configure(preview_config)
picam2.start()

blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임

win_hi = "High-Res"
win_lo = "Low-Res"

prev_time = time.time()

while True:
    frame_hd = picam2.capture_array("main")

    # ===== 실시간 출력용으로 저해상도 프레임 생성 =====
    frame_lowres = cv2.resize(frame_hd, LOW_RES, interpolation=cv2.INTER_AREA)
    cv2.imshow("Low-Res Preview (192x192)", frame_lowres)

    current_time = time.time()
    fps = 1.0 / (current_time - prev_time)
    fps_list.append(fps)
    prev_time = current_time

    print(f"FPS: {fps: .2f}")

    
    # ===== YOLO에 저해상도 프레임으로 사람만 탐지 요청 =====
    results = model(source=frame_lowres,imgsz=LOW_RES ,classes=[0])
    dets = results[0].boxes.xyxy.cpu().numpy()
    inference_time = results[0].speed["inference"]  # YOLOv8/v11은 리스트 반환
    inference_times.append(inference_time)

    # ===== 사람 탐지된 경우 고해상도 원본 ROI 출력 ====
    if dets is not None and len(dets) > 0:
        dets_to_show = dets[:2] if len(dets) > 2 else dets
        dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
        patches = []
        for box in dets_to_show:
            x1, y1, x2, y2 = map(int, box[:4])
            hr1, hr2 = int(x1*sx), int(y1*sy)
            hr3, hr4 = int(x2*sx), int(y2*sy)
            roi = frame_hd[hr2:hr4, hr1:hr3]
            if roi.size:
                patches.append(roi)
        if len(patches) > 1:
            h1, w1 = patches[0].shape[:2]
            h2, w2 = patches[1].shape[:2]
            canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
            canvas[:h1, :w1] = patches[0]
            canvas[:h2, w1:w1+w2] = patches[1]
            cv2.imshow(win_hi, canvas)
        else:
            cv2.imshow(win_hi, patches[0])
    else:
        cv2.imshow(win_hi, blank)  # 빈 프레임 표시
    
    # 'q'를 누르면 종료
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print(f"평균 fps: {sum(fps_list)/len(fps_list):.2f} ms")
        print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
        break


picam2.stop()
cv2.destroyAllWindows()

