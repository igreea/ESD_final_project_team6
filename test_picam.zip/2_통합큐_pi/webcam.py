import threading
import cv2
from ultralytics import YOLO
from queue import Queue, Empty, Full
import time
import numpy as np
from picamera2 import Picamera2
'''

'''

# 모델 로드 및 설정
model = YOLO("yolo11n.pt")
model.classes = [0]  # 사람 클래스만

# 해상도 설정
HIGH_RES = (1280, 1280)
LOW_RES = (192, 192)

# 고정 비율 X → 해상도 비율로 정확 변환
sx = HIGH_RES[0] / LOW_RES[0]
sy = HIGH_RES[1] / LOW_RES[1]

# 추론시간, fps측정
fps_list = []
inference_times = []

#picam
picam2 = Picamera2()
preview_config = picam2.create_preview_configuration(main={"size": HIGH_RES, "format":"RGB888"})
picam2.configure(preview_config)
picam2.start()

max_queue_size = 1
frame_queue = Queue(maxsize=max_queue_size)
det_queue = Queue(maxsize=max_queue_size)

win_hi = "High-Res"
win_lo = "Low-Res"
blank = np.zeros((640, 640, 3), dtype=np.uint8)  # 빈 프레임

cv2.namedWindow(win_hi, cv2.WINDOW_AUTOSIZE)
cv2.namedWindow(win_lo, cv2.WINDOW_NORMAL)
cv2.resizeWindow(win_lo, 640, 640) #640x640으로 크기 조정

prev_time = time.time()

HIGH_RES = (1280, 1280)  # 고해상도 해상도
LOW_RES = (192, 192)  # 저해상도 해상도
while True:
    high = picam2.capture_array("main")
    low = cv2.resize(high, LOW_RES, interpolation=cv2.INTER_AREA)

    try:
        frame_queue.get_nowait()
    except Empty:
        pass  # 큐가 비어 있으면 그대로 진행

    # 프레임 넣기 (실패해도 멈추지 않음)
    try:
        frame_queue.put((low, high), block=False)
    except Full:
        pass  # 안전하게 무시하고 다음 프레임으로 진행


    lo, hi_dis = frame_queue.get(timeout=0.05)
    cv2.imshow("Low-Res Preview (192*192)", lo)

    current_time = time.time()
    fps = 1.0 / (current_time - prev_time)
    fps_list.append(fps)
    prev_time = current_time  

    # ===== YOLO에 저해상도 프레임으로 사람만 탐지 요청 =====
    results = model(source=lo, imgsz=LOW_RES ,classes=[0])
    
    inference_time = results[0].speed["inference"]  # YOLOv8/v11은 리스트 반환
    inference_times.append(inference_time)

    dets = results[0].boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2]
    
    if det_queue.full():
        det_queue.get_nowait()
    det_queue.put(dets)


    try:
        dets = det_queue.get(timeout=0.05)
    except Empty:
        continue

    
    
    if dets is not None and len(dets) > 0:
        dets_to_show = dets[:2] if len(dets) > 2 else dets
        dets_to_show = sorted(dets_to_show, key=lambda x: x[0]) # detection 값이 sort되어야 안정적으로 ROI 출력 가능
        patches = []
        for box in dets_to_show:
            x1, y1, x2, y2 = map(int, box[:4])
            hr1, hr2 = int(x1*sx), int(y1*sy)
            hr3, hr4 = int(x2*sx), int(y2*sy)
            roi = hi_dis[hr2:hr4, hr1:hr3]
            if roi.size:
                patches.append(roi)
        if len(patches) > 1:
            h1, w1 = patches[0].shape[:2]
            h2, w2 = patches[1].shape[:2]
            canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=patches[0].dtype)
            canvas[:h1, :w1] = patches[0]
            canvas[:h2, w1:w1+w2] = patches[1]
            cv2.imshow(win_hi, canvas)
        else:
            cv2.imshow(win_hi, patches[0])
    else:
        cv2.imshow(win_hi, blank)  # 빈 프레임 표시

    if cv2.waitKey(1) & 0xFF == ord('q'):
        print(f"평균 fps: {sum(fps_list)/len(fps_list):.2f} ")
        print(f"평균 Inference Time: {sum(inference_times) / len(inference_times):.2f} ms")
        break


picam2.stop()
cv2.destroyAllWindows()


